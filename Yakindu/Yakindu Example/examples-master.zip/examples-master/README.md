# examples
YAKINDU Statechart Tools examples.

This repository is used in the tool to fetch examples. If you think you have a good example as well, feel free to create a pull request! User contributions are very welcome.
